<html>
<head>
<title>Hello Bangladesh</title>
</head>
<body>

<p class="a b" id="x" title="hello">
Hello Bangladesh  
How Are you</p>

<pre>Hello America
How are things??
How is capital city??
</pre>
<div> hello world</div>
<div> he<span style="color:red">llo<span style="color:blue"> world</div><br>

&copy;  &reg; &amp; &quot; &apos; &lt; &gt; <br><br>
    
    &#34; &#38; &#39; &#169; &#174; &#60; &#160; &#62;
    
    
    <ol start='4' type='i'>
  <li><a href="https://www.w3schools.com/">W3Schools</a></li>
  <li>Tea</li>
  <li>Milk</li>
</ol>

<ul type= "circle"  >
  <li>Bangladesh</li>
  <li>Nepal</li>
  <li>Bhutan</li>
</ul>

<ul type="square">
  <li>Coffee</li>
  <li>Tea
    <ul>
      <li>Black tea</li>
      <li>Green tea</li>
    </ul>
  </li>
  <li>Milk</li>
</ul>


<dl >
  <dt>Who</dt>
  <dd>- whorld health organization</dd>
  <dt>Usa</dt>
  <dd>- United states</dd>

  <dt>Uk</dt>
  <dd>- United kingdom</dd>

</dl>

<select name="forma" onchange="location = this.value">
 <option value="">Select</option>
 <option value="https://www.google.com">Contact</option>
 <option value="signup.php">Sitemap</option>
</select>

</body>

</html>