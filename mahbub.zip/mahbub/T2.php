<?php

Class car
{

	protected $title;
	protected $model;

	public function read()
	{

		echo "reading"."<br>"."driving";
	}
	public function __construct($tle, $mod)
	{
    $this->title = $tle;
       $this->model = $mod;
	}


	
}
 

Class book extends car 
{

	public function getcolor()
	{
     return $this->title ."<br>". $this->model ;
	}
} 
$car1 = new book("jeep","5007");

  $car1->read();
  echo $car1->getcolor();
?>