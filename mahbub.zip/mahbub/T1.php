<?php

// Class car
// {

// 	public $title="Suv";
// 	public $model="2001";

// 	public function read()
// 	{

// 		echo "reading";
// 	}
// }
//  $car1 = new car();
//   echo $car1->title."<br><br>";
//    echo $car1->model. "<br>";


// $i=1;

// While($i<=10)
// {
// 	echo"Hello world<br>";
// 	++$i;
	
// }
// Class car
// {

// 	protected $title="Suv";
// 	//protected $model="2001";

// 	public function read()
// 	{

// 		echo "reading"."<br>"."driving";
// 	}

// 	public function set_title($value)
// 	{

// 		$this ->title=$value;
// 	}

// 	public function get_title()
// 	{

// 		return $this ->title;
// 	}
// }
//  $car1 = new car();
// echo $car1->set_title("my")."<br>";
//   echo $car1->get_title()."<br>";
//    //echo $car1->model. "<br>";
//   $car1->read();

  Class book
{

	protected $title ;
	protected $model ;

	public function read()
	{

		echo "reading"."<br>"."driving";
	}

	public function __construct($tle, $mod)
	{
    $this->title = $tle;
       $this->model = $mod;
	}

	public function getcolor()
	{
     return $this->title ."<br>". $this->model ;
	}
}
 $car1 = new book("Jeep","4008");

  
  echo $car1->getcolor();



   


?>